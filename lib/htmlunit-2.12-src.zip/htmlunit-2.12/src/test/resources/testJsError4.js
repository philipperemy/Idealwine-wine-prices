/**
bla bla bla
and bla bla
*/

// my wonderful code... with an error

foo.bla = 456;
